#!/bin/bash

  if [ "$1" = "-help" ]; then
      echo "Uso: backup_full.sh ORIGEN DESTINO"
      echo "Ejemplo: backup_full.sh /var/log /backup_dir"
      echo "Genera DESTINO/NOMBRE_bkp_AAAAMMDD.tar.gz"
      exit 0
  fi

  if [ $# -ne 2 ]; then
      echo "Error: faltan argumentos. Usa -help para ver la ayuda."
      exit 1
  fi

  ORIGEN=$1
  DESTINO=$2

  for DIR in "$ORIGEN" "$DESTINO"; do
      if [ ! -d "$DIR" ]; then
          echo "Error: $DIR no existe"
          exit 1
      fi
      if grep -q " $DIR " /etc/fstab && ! mountpoint -q "$DIR"; then
          echo "Error: $DIR no esta montado"
          exit 1
      fi
  done

  NOMBRE=$(basename "$ORIGEN")
  ARCHIVO="$DESTINO/${NOMBRE}_bkp_$(date +%Y%m%d).tar.gz"

  tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE" || exit 1
  echo "Backup generado: $ARCHIVO"