 poweroff
 poweroff
pwd
ls
ls -a
ls -l
ls -la
hostnamectl set-hostname TPServer
nano /etc/hosts
nano ../etc/hosts
nano ./etc/hosts
cd ..
ls
cd etc/
ls
cd hosts
cd ..
cd home
ls -a
ls -la
exit
apt
apt install 
apt install ssh
apt install openssh-client
ssh
apt update
ip -a
ip a
nano /etc/ssh/sshd_config
cat /etc/ssh/sshd_config
nano
cat
cat /etc/ssh/sshd_config
apt updat
apt update
cat /etc/os-release | head -3
cat /etc/apt/source.list
cat /etc/apt/sources.list
apt install nano openssh-server
apt install nano openssh
apt install nano 
apt install nano
vi /etc/ssh/sshd_confg
vi /etc/ssh/sshd_config
clear
openssh
cat /etc/os-release | head -3
apt update
systemctl status ssh
systemctl status sshd
cat /etc/apt/source.list
cat /etc/apt/sources.list
 /etc/apt/source.list
vi /etc/apt/sources.list
systemctl restart apt
systemctl restart apt-daily.service 
apt update
exit
apt update
vi /etc/apt/sources.list
apt-get
apt-get clean
apt-get update
wget
wget https://google.com
ip -a
ip a
vi /etc/network/interfaces
clear
systemctl restart networking.service 
systemctl status networking.service 
ip a
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
clear
vi /etc/network/interfaces
systemctl restart networking.service 
poweroff
apt install -y apache2 php libapache2-mod-php php-mysql
ls
exit
ip a
apt update
apt install openssh-client

systemctl status ssh
apt install ssh
vi /etc/apt/sources.list
apt install ssh
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
vi /etc/apt/sources.list
apt update
apt install openssh-client
systemctl status ssh
apt install openssh
apt install ssh
vi /etc/apt/sources.list
apt install openssh-server nano
ip a
vi /etc/apt/sources.list
ls /etc/apt/sources.list.d/
ls /etc/apt/sources.list.d/
vi /etc/apt/sources.list
apt install openssh-server nano
apt update
apt install openssh
apt install openssh-client
apt install nano
nano
systemctl status ssh
systemctl status openssh
systemctl enable --now ssh
apt install openssh-server
systemctl enable --now ssh
systemctl status ssh
nano /etc/ssh/sshd_config
systemctl restart ssh
ip a
nano /etc/network/interfaces
systemctl restart networking.service 
ip a
nano /etc/ssh/sshd_config
systemctl restart ssh.service 
nano /etc/ssh/sshd_config
nano /etc/network/interfaces
systemctl restart networking.service 
systemctl restart networking.service 
systemctl satus networking.service 
systemctl status networking.service 
apt install -y apache2 php libapache2-mod-php php-mysql
systemctl enable --now apache2 
php -v
nano /etc/network/interfaces
systemctl restart networking.service 
rm /var/www/html/index.html
ls -l /var/www/html
systemctl restart networking.service 
systemctl status apache2
nano /etc/network/interfaces
systemctl restart networking.service 
apt install mariadb-server
systemctl enable --now mariadb
systemctl status mariadb
nano /etc/network/interfaces
systemctl restart networking.service 
grep -iE 'create database|user ' /root/db.sql 
mysql < /root/db.sql 
grep -iE 'mysqli|pdo|localhost'/var/www/html/index.php
grep -iE 'mysqli|pdo|localhost'/var/www/html/index.php
mysql -u root -p
ip a
poweroff
ip a→→→
nano /etc/network/interfaces
nano /etc/network/interfaces
nano /etc/network/interfaces
systemctl restart networking.service 
ip a
poweroff
lsblk
poweroff
lbslj
lbslk
lsblk 
fdisk /dev/sdc
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir /backup_dir
ls -A /www_dir /backup_dir
cp /etc/fstab /etc/fstab.bak
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 0 2" 
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 0 
poweroff
poweroff
apt install virtualbox-guest-x11
apt update
nano /etc/network/interfaces
systemctl restart networking.service 
apt install virtualbox-guest-x11
apt update
apt install virtualbox-guest-x11
apt install virtualbox-guest
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2) /backup_dir ext4 0 2" >> /etc/fstab
mount -a
sed -i 's/ ext4 0 2/ ext4 defaults 0 2' /etc/fstab
sed -i "s/ ext4 0 2/ ext4 defaults 0 2" /etc/fstab
sed -i 's/ ext4 0 2/ ext4 defaults 0 2/' /etc/fstab
cat /etc/ftab
cat /etc/fstab
mount -a
df -h /www_dir /backup_dir
ls /var/www/html
cp /var/www/html/index.php /var/www/html/logo.png /www_dir/
ls -l /www_dir
sed -i 's|DocumentRoot /var/www/html|' /etc/apache2/sites-available/000-default.conf
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /www_dir' /etc/apache2/sites-available/000-default.conf
sed -i 's|DocumentRoot /var/www/html|DocumentRoot /www_dir|' /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.bak
cat >> /etc/apache2/apache2.conf << 'EOF'
<Directory /www_dir/>
Options Indexes FollowSymLinks
AllowOverride None
Require all granted
</Directory>
EOF

tail -6 /etc/apache2/apache2.conf
apache2ctl configtest
systemctl restart apache2
nano /etc/network/interfaces
systemctl restart apache2
systemctl restart networking.service 
cat /proc/partitions > /root/particion
cat /root/particion 
mkdir -p /opt/scripts
nano /etc/network/interfaces
systemctl restart networking.service 
cd /opt/scripts/
poweroff
VBoxClient --clipboard
apt update
apt install virtualbox-guest-x11
apt install virtualbox-guest-dkms
apt install virtualbox-guest-utils
nano /etc/network/interfaces
systemctl  restart networking.service 

systemctl  restart networking.service 
cd /opt/scripts/
wget https://download944.mediafire.com/orz3ib077ipgnEaRiS9nto-KDCc-4gi6VGLt1QnaXv5jlpToSTr7p74OIB1F8U2oy_2WBinvX0S4YSC0oiMSAIGVqNlRWiUAqZTXi0rSEowwc-aR1DG55kb_aPueTTHI9E7w2UpYfvAVf0UyNavit9E3WgWkDcpylXe8J3KfW8vhcA/56lkx5y8pmat8uv/backup_full.sh
nano /etc/network/interfaces
cd /opt/scripts/
wget https://download944.mediafire.com/orz3ib077ipgnEaRiS9nto-KDCc-4gi6VGLt1QnaXv5jlpToSTr7p74OIB1F8U2oy_2WBinvX0S4YSC0oiMSAIGVqNlRWiUAqZTXi0rSEowwc-aR1DG55kb_aPueTTHI9E7w2UpYfvAVf0UyNavit9E3WgWkDcpylXe8J3KfW8vhcA/56lkx5y8pmat8uv/backup_full.sh
systemctl  restart networking.service 
wget https://download944.mediafire.com/orz3ib077ipgnEaRiS9nto-KDCc-4gi6VGLt1QnaXv5jlpToSTr7p74OIB1F8U2oy_2WBinvX0S4YSC0oiMSAIGVqNlRWiUAqZTXi0rSEowwc-aR1DG55kb_aPueTTHI9E7w2UpYfvAVf0UyNavit9E3WgWkDcpylXe8J3KfW8vhcA/56lkx5y8pmat8uv/backup_full.sh
chmod +x /opt/scripts/backup_full.sh 
cd ..
cd ..
cd home
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh
nano /opt/scripts/backup_full.sh 
y
/opt/scripts/backup_full.sh
sed -i 's/r
sed -i 's\r$//' /opt/scripts/backup_full.sh 
sed -i 's\r$//' /opt/scripts/backup_full.sh
sed -i 's/\r$//' /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh 
/opt/scripts/backup_full.sh  --help
/opt/scripts/backup_full.sh  -help
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -l /backup_dir/
(crontab -l 2>/dev/null; echo "0 0 * * * /opt/scripts/backup_full.sh /var/log /backup_dir"; echo "0 23 * * 1,3,5 /opt/scripts/backup_full.sh /www_dir /backup_dir") | crontab -
crontab -l
poweroff
